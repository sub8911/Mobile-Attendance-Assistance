package com.sub.studentinfosys.mobile_attendance_assistance.ADAPTERS;

import com.sub.studentinfosys.mobile_attendance_assistance.MODELS.AttendanceSheet;

/**
 * Created by Sagar on 3/3/2017.
 */

public interface ClickEditAttendance {
    public void setValues(AttendanceSheet al, int position);
}
