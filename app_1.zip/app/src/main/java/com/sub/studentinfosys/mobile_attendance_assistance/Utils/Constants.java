package com.sub.studentinfosys.mobile_attendance_assistance.Utils;

public interface Constants {

    String KEY_ID = "keyId";

    String NAME_INNER_CONTAINER = "innerContainer";

}
