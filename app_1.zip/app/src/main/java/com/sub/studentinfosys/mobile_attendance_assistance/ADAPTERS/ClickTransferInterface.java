package com.sub.studentinfosys.mobile_attendance_assistance.ADAPTERS;

import android.database.Cursor;

/**
 * Created by Sagar on 2/28/2017.
 */

public interface ClickTransferInterface {
    public void setValues(Cursor al);
}
